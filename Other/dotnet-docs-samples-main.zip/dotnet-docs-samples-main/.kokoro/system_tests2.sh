#!/bin/bash
set -ex
pwd
cd github/dotnet-docs-samples/.kokoro
pwsh main.ps1 2