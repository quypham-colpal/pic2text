﻿using System;
using System.Windows.Forms;

namespace AutoCopy
{
    public partial class UserControl1 : UserControl
    {
        public UserControl1()
        {
            InitializeComponent();
        }

        private void btn_load_Click(object sender, EventArgs e)
        {
            
        }
    }
}
